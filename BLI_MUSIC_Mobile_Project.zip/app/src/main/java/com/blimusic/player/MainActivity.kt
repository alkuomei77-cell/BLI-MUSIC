package com.blimusic.player

import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Bg = Color(0xFF09070D)
private val Panel = Color(0xFF17121F)
private val Purple = Color(0xFFB52BFF)

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null
    private var equalizer: Equalizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BliApp(
            onPickAudio = { uri -> playAudio(uri) },
            onVolume = { value -> player?.setVolume(value, value) },
            onEq = { band, value -> setEq(band, value) }
        ) }
    }

    private fun playAudio(uri: Uri) {
        try {
            player?.release()
            equalizer?.release()
            player = MediaPlayer().apply {
                setAudioStreamType(AudioManager.STREAM_MUSIC)
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { mp ->
                    mp.start()
                    try { equalizer = Equalizer(0, mp.audioSessionId).apply { enabled = true } }
                    catch (_: Exception) { }
                }
                prepareAsync()
            }
        } catch (_: Exception) { }
    }

    private fun setEq(index: Int, value: Float) {
        try {
            val eq = equalizer ?: return
            if (index < eq.numberOfBands) {
                val range = eq.bandLevelRange
                val level = (range[0] + (value / 100f) * (range[1] - range[0])).toInt()
                eq.setBandLevel(index.toShort(), level.toShort())
            }
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        player?.release()
        equalizer?.release()
        super.onDestroy()
    }
}

@Composable
private fun BliApp(
    onPickAudio: (Uri) -> Unit,
    onVolume: (Float) -> Unit,
    onEq: (Int, Float) -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var selectedName by remember { mutableStateOf("اختار أغنية من جهازك") }
    var playing by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(0.8f) }
    val eqValues = remember { mutableStateListOf(50f, 50f, 50f, 50f, 50f) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { onPickAudio(uri); selectedName = uri.lastPathSegment ?: "ملف صوتي"; playing = true }
            catch (_: Exception) { }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Bg, surface = Panel, onBackground = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(
                Modifier.fillMaxWidth().padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("BLI", color = Color.White, fontSize = 27.sp)
                Text(" MUSIC", color = Purple, fontSize = 27.sp)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.GraphicEq, null, tint = Purple)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("المشغل", "المعادل", "المتصفح").forEachIndexed { i, label ->
                    FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) })
                }
            }
            when (tab) {
                0 -> Column(
                    Modifier.fillMaxSize().padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.MusicNote, null, tint = Purple, modifier = Modifier.size(110.dp))
                    Text(selectedName, color = Color.White, modifier = Modifier.padding(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }) {
                            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("اختيار أغنية")
                        }
                        FilledTonalButton(onClick = { playing = !playing }) {
                            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                        }
                    }
                    Spacer(Modifier.height(26.dp))
                    Text("مستوى الصوت", color = Color.White)
                    Slider(value = volume, onValueChange = { volume = it; onVolume(it) })
                    Text("${(volume * 100).toInt()}%", color = Purple)
                }
                1 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
                    Text("معادل صوت بخمسة نطاقات", color = Color.White, fontSize = 20.sp)
                    Text("التأثير يعتمد على دعم جهازك للصوتيات", color = Color.LightGray, fontSize = 12.sp)
                    val names = listOf("Bass", "Low Mid", "Mid", "High Mid", "Treble")
                    names.forEachIndexed { i, name ->
                        Text(name, color = Color.White)
                        Slider(value = eqValues[i], onValueChange = {
                            eqValues[i] = it
                            onEq(i, it)
                        })
                    }
                    Text("حرّك Bass لزيادة أو تقليل إحساس البيز.", color = Color.LightGray)
                }
                else -> BrowserPage()
            }
        }
    }
}

@Composable
private fun BrowserPage() {
    var address by remember { mutableStateOf("https://www.google.com") }
    var currentUrl by remember { mutableStateOf("https://www.google.com") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = address, onValueChange = { address = it },
                modifier = Modifier.weight(1f), singleLine = true,
                label = { Text("عنوان الموقع") }
            )
            IconButton(onClick = {
                currentUrl = if (address.startsWith("http")) address else "https://$address"
            }) { Icon(Icons.Default.ArrowForward, null, tint = Purple) }
        }
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    loadUrl(currentUrl)
                }
            },
            update = { it.loadUrl(currentUrl) }
        )
    }
}
